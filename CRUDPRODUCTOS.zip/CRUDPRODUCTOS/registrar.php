<?php
header('Content-Type: application/json');
require_once __DIR__ . '/Modelo/Productos.php';

$producto = new Producto();
$accion = $_POST['Accion'] ?? '';

switch ($accion) {

    case 'Guardar':
        $producto->codigo   = $_POST['codigo']   ?? '';
        $producto->producto = $_POST['producto']  ?? '';
        $producto->precio   = $_POST['precio']    ?? 0;
        $producto->cantidad = $_POST['cantidad']  ?? 0;
        echo json_encode($producto->guardar());
        break;

    case 'Modificar':
        $producto->id       = $_POST['id']        ?? '';
        $producto->codigo   = $_POST['codigo']    ?? '';
        $producto->producto = $_POST['producto']  ?? '';
        $producto->precio   = $_POST['precio']    ?? 0;
        $producto->cantidad = $_POST['cantidad']  ?? 0;
        echo json_encode($producto->editar());
        break;

    case 'Buscar':
        $producto->codigo = $_POST['codigo'] ?? '';
        echo json_encode($producto->buscar());
        break;

    case 'Listar':
        echo json_encode($producto->listar());
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Acción no válida']);
        break;
}