// Buscar producto por código
function buscarProducto() {
    let codigo = document.getElementById('codigo').value;

    if (!codigo) {
        Swal.fire('Atención', 'Ingresa un código para buscar', 'warning');
        return;
    }

    let formData = new FormData();
    formData.append('Accion', 'Buscar');
    formData.append('codigo', codigo);

    fetch('registrar.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            let p = data.datos;
            document.getElementById('id').value       = p.id;
            document.getElementById('codigo').value   = p.codigo;
            document.getElementById('producto').value = p.producto;
            document.getElementById('precio').value   = p.precio;
            document.getElementById('cantidad').value = p.cantidad;
            document.getElementById('accion').value   = 'Modificar';
            document.getElementById('btnSubmit').textContent = 'Actualizar';
            Swal.fire('¡Encontrado!', 'Producto cargado correctamente', 'success');
        } else {
            Swal.fire('No encontrado', data.message, 'error');
        }
    })
    .catch(err => console.error('Error al buscar:', err));
}

// Listar productos al cargar la página
function ListarProductos() {
    let formData = new FormData();
    formData.append('Accion', 'Listar');

    fetch('registrar.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        let tabla = document.getElementById('tablaProductos');
        tabla.innerHTML = '';

        data.forEach(p => {
            tabla.innerHTML += `
                <tr>
                    <td>${p.id}</td>
                    <td>${p.codigo}</td>
                    <td>${p.producto}</td>
                    <td>${p.precio}</td>
                    <td>${p.cantidad}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="cargarProducto('${p.codigo}')">Editar</button>
                    </td>
                </tr>`;
        });
    })
    .catch(err => console.error('Error al listar:', err));
}

// Cargar producto en el formulario para editar
function cargarProducto(codigo) {
    let formData = new FormData();
    formData.append('Accion', 'Buscar');
    formData.append('codigo', codigo);

    fetch('registrar.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            let p = data.datos;
            document.getElementById('id').value       = p.id;
            document.getElementById('codigo').value   = p.codigo;
            document.getElementById('producto').value = p.producto;
            document.getElementById('precio').value   = p.precio;
            document.getElementById('cantidad').value = p.cantidad;
            document.getElementById('accion').value   = 'Modificar';
            document.getElementById('btnSubmit').textContent = 'Actualizar';
        } else {
            Swal.fire('Error', data.message, 'error');
        }
    })
    .catch(err => console.error('Error al buscar:', err));
}

// Listar al cargar y asignar eventos
document.addEventListener('DOMContentLoaded', () => {
    ListarProductos();
    document.getElementById('btnBuscar').addEventListener('click', buscarProducto);
});

document.getElementById('formProducto').addEventListener('submit', function(e) {
    e.preventDefault();

    let accion = document.getElementById('accion').value;
    let formData = new FormData(this);
    formData.append('Accion', accion);

    fetch('registrar.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        switch (data.accion) {
            case 'guardar':
                if (data.success) {
                    Swal.fire('¡Éxito!', data.message, 'success');
                    document.getElementById('formProducto').reset();
                    ListarProductos();
                } else {
                    Swal.fire('Error', data.errors.join('\n'), 'error');
                }
                break;

            case 'editar':
                if (data.success) {
                    Swal.fire('¡Actualizado!', data.message, 'success');
                    document.getElementById('formProducto').reset();
                    document.getElementById('accion').value = 'Guardar';
                    document.getElementById('btnSubmit').textContent = 'Registrar';
                    ListarProductos();
                } else {
                    Swal.fire('Error', data.message || data.errors.join('\n'), 'error');
                }
                break;

            default:
                Swal.fire('Error', 'Respuesta inesperada', 'error');
        }
    })
    .catch(err => {
        Swal.fire('Error', 'No se pudo conectar con el servidor', 'error');
        console.error(err);
    });
});