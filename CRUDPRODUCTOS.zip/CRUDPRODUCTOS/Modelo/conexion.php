<?php
class DB {
    private static $instancia = null;
    private $conexion;

    private function __construct() {
        try {
            $this->conexion = new PDO(
                'mysql:host=localhost;dbname=productosdb;charset=utf8',
                'root',
                '',
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
        } catch (PDOException $e) {
            die(json_encode(['success' => false, 'message' => 'Error de conexión: ' . $e->getMessage()]));
        }
    }

    public static function getInstancia() {
        if (self::$instancia === null) {
            self::$instancia = new DB();
        }
        return self::$instancia;
    }

    public function getConexion() {
        return $this->conexion;
    }

    public function insertSeguro($sql, $params = []) {
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute($params);
        return $this->conexion->lastInsertId();
    }

    public function updateSeguro($sql, $params = []) {
        $stmt = $this->conexion->prepare($sql);
        return $stmt->execute($params);
    }

    public function query($sql, $params = []) {
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}