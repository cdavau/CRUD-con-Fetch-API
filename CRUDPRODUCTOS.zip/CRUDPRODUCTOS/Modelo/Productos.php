<?php
require_once __DIR__ . '/conexion.php';

class Producto {
    private $db;
    public $id;
    public $codigo;
    public $producto;
    public $precio;
    public $cantidad;

    public function __construct() {
        $this->db = DB::getInstancia();
    }

    private function validar() {
        $errores = [];
        if (empty($this->codigo)) $errores[] = 'El código es obligatorio';
        if (empty($this->producto)) $errores[] = 'El nombre del producto es obligatorio';
        if (!is_numeric($this->precio) || $this->precio <= 0) $errores[] = 'El precio debe ser mayor a 0';
        if (!is_numeric($this->cantidad) || $this->cantidad < 0) $errores[] = 'La cantidad no puede ser negativa';
        return $errores;
    }

    public function guardar() {
        $errores = $this->validar();
        if (!empty($errores)) {
            return ['success' => false, 'errors' => $errores];
        }

        $id = $this->db->insertSeguro(
            'INSERT INTO productos (codigo, producto, precio, cantidad) VALUES (?, ?, ?, ?)',
            [$this->codigo, $this->producto, $this->precio, $this->cantidad]
        );

        return ['success' => true, 'message' => 'Producto guardado correctamente', 'accion' => 'guardar', 'id' => $id];
    }

    public function editar() {
        $errores = $this->validar();
        if (!empty($errores)) {
            return ['success' => false, 'errors' => $errores];
        }

        $resultado = $this->db->updateSeguro(
            'UPDATE productos SET codigo=?, producto=?, precio=?, cantidad=? WHERE id=?',
            [$this->codigo, $this->producto, $this->precio, $this->cantidad, $this->id]
        );

        if ($resultado) {
            return ['success' => true, 'message' => 'Producto actualizado correctamente', 'accion' => 'editar'];
        }
        return ['success' => false, 'message' => 'Error al actualizar el producto'];
    }

    public function buscar() {
        $resultado = $this->db->query(
            'SELECT * FROM productos WHERE codigo = ?',
            [$this->codigo]
        );

        if (!empty($resultado)) {
            return ['success' => true, 'accion' => 'buscar', 'datos' => $resultado[0]];
        }
        return ['success' => false, 'message' => 'Producto no encontrado'];
    }

    public function listar() {
        return $this->db->query('SELECT * FROM productos');
    }
}